import{a as o}from"./createLucideIcon-CnV6jV_3.js";const e=[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]],c=o("X",e);export{c as X};
