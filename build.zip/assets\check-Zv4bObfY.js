import{a as c}from"./createLucideIcon-CnV6jV_3.js";const e=[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]],t=c("Check",e);export{t as C};
