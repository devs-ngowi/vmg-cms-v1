import{a as o}from"./createLucideIcon-CnV6jV_3.js";const t=[["path",{d:"m9 18 6-6-6-6",key:"mthhwq"}]],h=o("ChevronRight",t);export{h as C};
