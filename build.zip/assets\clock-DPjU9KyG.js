import{a as c}from"./createLucideIcon--V6ocER-.js";const o=[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["polyline",{points:"12 6 12 12 16 14",key:"68esgv"}]],i=c("Clock",o);export{i as C};
