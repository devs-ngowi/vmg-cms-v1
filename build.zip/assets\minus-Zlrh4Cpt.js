import{a as o}from"./createLucideIcon--V6ocER-.js";const s=[["path",{d:"M5 12h14",key:"1ays0h"}]],c=o("Minus",s);export{c as M};
