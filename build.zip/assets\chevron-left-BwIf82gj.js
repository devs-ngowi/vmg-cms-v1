import{a as e}from"./createLucideIcon--V6ocER-.js";const o=[["path",{d:"m15 18-6-6 6-6",key:"1wnfg3"}]],n=e("ChevronLeft",o);export{n as C};
