import{a as e}from"./createLucideIcon--V6ocER-.js";const o=[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"M12 5v14",key:"s699le"}]],a=e("Plus",o);export{a as P};
