import{a as e}from"./createLucideIcon-CnV6jV_3.js";const o=[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]],c=e("LoaderCircle",o);export{c as L};
